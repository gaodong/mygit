public class Server {
	//
	private ServerSocket serverSocket;
	    
}
